# map-silhouettes

Four folded-map silhouette shapes, all filled in OHM dark teal (#1a4a52) on a white background.

| File | Description |
|------|-------------|
| 01-canonical-silhouette.svg | Crisp v0.1/v0.2 polygon — 10 sharp-cornered vertices in 100×100 viewBox |
| 02-organic-silhouette.svg | Hand-feel variation — same vertices jittered ±1.2 units with bumpy Q-curve edges, 100×100 viewBox |
| 03-opentrailmap-silhouette.svg | OpenTrailMap logo outer silhouette — rounded corners, native 526×526 viewBox |
| 04-public-domain-map-silhouette.svg | Public Domain Map logo outer silhouette — sharp corners, native 500×500 viewBox |

Note: OTM and PDM silhouettes are in their native coordinate spaces and will appear
at different sizes if displayed at 1:1 pixel scale. Scale via CSS/SVG width/height as needed.
